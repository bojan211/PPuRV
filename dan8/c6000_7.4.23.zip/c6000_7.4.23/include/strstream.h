// strstream.h standard header
#ifndef _STRSTREAM_H_
#define _STRSTREAM_H_
#include <strstream>

 #if _HAS_NAMESPACE
using namespace std;
 #endif /* _HAS_NAMESPACE */

#endif /* _FSTREAM_ */

/*
 * Copyright (c) 1992-2004 by P.J. Plauger.  ALL RIGHTS RESERVED.
 * Consult your license regarding permissions and restrictions.
V4.02:1476 */
